---
title: about
layout: page
---

Welcome to Jackpon GitBlog ！
----------------------------
这是我的个人博客，当初建此网站的初心是为了整理自己的编程过程，可以当做是我的电子日志吧。
**附上联系方式：**


 - 邮箱：JackpongWong@163.com
 - 知乎：[欢迎一起来讨论][1]
 - GitHub：[Jackpon][2]


  [1]: https://www.zhihu.com/people/Jackpon
  [2]: https://github.com/Jackpon
